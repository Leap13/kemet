<?php
/**
 * Kemet_After_Setup_Theme initial setup
 *
 * @package     Kemet
 * @author      Kemet
 * @copyright   Copyright (c) 2019, Kemet
 * @link        https://kemet.io/
 */

if ( ! class_exists( 'Kemet_After_Setup_Theme' ) ) {

	/**
	 * Kemet_After_Setup_Theme initial setup
	 */
	class Kemet_After_Setup_Theme {

		/**
		 * Instance
		 *
		 * @var $instance
		 */
		private static $instance;

		/**
		 * Initiator
		 *
		 * @return object
		 */
		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Constructor
		 */
		public function __construct() {
			add_action( 'after_setup_theme', array( $this, 'setup_theme' ), 2 );
			add_action( 'init', array( $this, 'register_style_variations' ), 20 );
			add_filter( 'wp_theme_json_data_theme', array( $this, 'add_style_variations' ), 10, 1 );
			add_filter( 'wp_get_global_stylesheet', array( $this, 'ensure_style_variations' ), 10, 1 );
			add_action( 'rest_api_init', array( $this, 'ensure_style_variations_rest' ), 20 );
			add_filter( 'rest_request_before_callbacks', array( $this, 'fix_style_variations_permissions' ), 10, 3 );
		}

		/**
		 * Setup theme
		 */
		function setup_theme() {

			// Adding support for core block visual styles.
			add_theme_support( 'wp-block-styles' );

			// Adding support for responsive embedded content.
			add_theme_support( 'responsive-embeds' );

			// Adding support for nav menus
			add_theme_support( 'block-nav-menus' );

			// Add support for editor styles.
			add_theme_support( 'editor-styles' );

			// Note: editor-style-variations is not a real WordPress theme support
			// Style variations are automatically detected from /styles directory

			// Add support for global styles
			add_theme_support( 'global-styles' );

			// Add support for block templates (required for FSE)
			add_theme_support( 'block-templates' );

			// Add support for block template parts (required for FSE)
			add_theme_support( 'block-template-parts' );

			// Add support for wide alignment
			add_theme_support( 'align-wide' );

			// Add support for custom line height
			add_theme_support( 'custom-line-height' );

			// Add support for custom units
			add_theme_support( 'custom-units' );

			// Add support for custom spacing
			add_theme_support( 'custom-spacing' );

			// Language support
			load_theme_textdomain( 'kemet', KEMET_THEME_DIR . 'languages' );
		}

		/**
		 * Register style variations for Browse Styles feature
		 */
		function register_style_variations() {
			// WordPress automatically detects style variations from the /styles directory
			// when add_theme_support( 'editor-style-variations' ) is called
			// This function is kept for potential future enhancements
		}

		/**
		 * Add style variations to theme data
		 */
		function add_style_variations( $theme_data ) {
			// This filter helps WordPress recognize style variations
			return $theme_data;
		}

		/**
		 * Ensure style variations are loaded
		 */
		function ensure_style_variations( $stylesheet ) {
			// Clear any cached style data to ensure fresh detection
			delete_transient( 'wp_core_block_css_files' );
			return $stylesheet;
		}

		/**
		 * Ensure style variations are available in REST API
		 */
		function ensure_style_variations_rest() {
			// Force WordPress to re-scan for style variations
			if (class_exists('WP_Theme_JSON_Resolver')) {
				// Clear any cached data
				wp_cache_delete('theme_json_resolver_theme', 'themes');
				wp_cache_delete('theme_json_resolver_user', 'themes');
			}
		}

		/**
		 * Fix style variations permissions for Browse Styles feature
		 */
		function fix_style_variations_permissions( $response, $handler, $request ) {
			// Check if this is a request for style variations
			if (strpos($request->get_route(), '/global-styles/themes/') !== false && 
				strpos($request->get_route(), '/variations') !== false) {
				
				// Ensure user has edit_posts capability for Browse Styles
				if (!current_user_can('edit_posts')) {
					// Temporarily grant edit_posts capability for this request
					$user = wp_get_current_user();
					if ($user && $user->ID) {
						$user->add_cap('edit_posts');
					}
				}
			}
			
			return $response;
		}

	}
}

Kemet_After_Setup_Theme::get_instance();
