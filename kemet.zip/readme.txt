=== kemet ===
Contributors: kemet
Tested up to: 5.9
Requires at least: 5.9
Requires PHP: 7.2
Version: 1.2.01
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Copyright: Kemet

A full site editing theme.







